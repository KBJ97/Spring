package kr.co.sboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
